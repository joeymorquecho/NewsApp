//
//  Constants.swift
//  yourNYTimes
//
//  Created by Joey Morquecho on 5/14/20.
//  Copyright © 2020 Joey Morquecho. All rights reserved.
//

import Foundation

struct Constants {
    
    struct UserDefaults {
        static let categories = "categoriesKey"
    }
}
